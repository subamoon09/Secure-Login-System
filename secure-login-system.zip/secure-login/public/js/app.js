/* ── Simple SPA Router ─────────────────────────────────────── */
const app = document.getElementById('app');

const router = {
  routes: {},
  register(path, fn) { this.routes[path] = fn; },
  navigate(path) {
    window.history.pushState({}, '', path);
    this.render(path);
  },
  render(path) {
    const fn = this.routes[path] || this.routes['404'];
    if (fn) fn();
  }
};

window.addEventListener('popstate', () => router.render(location.pathname));

/* ── API helpers ───────────────────────────────────────────── */
async function api(method, endpoint, body) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch('/api/auth' + endpoint, opts);
  return res.json();
}

/* ── Utility ───────────────────────────────────────────────── */
function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
}

function showAlert(container, type, messages) {
  const old = container.querySelector('.alert');
  if (old) old.remove();
  const msgs = Array.isArray(messages) ? messages : [messages];
  const div = el('div', `alert alert-${type}`);
  msgs.forEach(m => {
    const p = el('div', 'alert-item');
    p.textContent = m;
    div.appendChild(p);
  });
  container.prepend(div);
}

function setLoading(btn, loading, label = 'Submit') {
  if (loading) {
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner"></span>`;
  } else {
    btn.disabled = false;
    btn.textContent = label;
  }
}

function timeAgo(isoStr) {
  if (!isoStr) return 'Never';
  const diff = Date.now() - new Date(isoStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function passwordStrength(pwd) {
  let score = 0;
  if (pwd.length >= 8) score++;
  if (/[A-Z]/.test(pwd)) score++;
  if (/[0-9]/.test(pwd)) score++;
  if (/[!@#$%^&*(),.?":{}|<>]/.test(pwd)) score++;
  if (pwd.length >= 12) score++;
  return score; // 0-5
}

/* ── Pages ─────────────────────────────────────────────────── */

/* REGISTER ──────────────────────────────────────────────────── */
function renderRegister() {
  app.innerHTML = `
  <div class="page">
    <div class="card">
      <div class="brand">
        <div class="brand-icon">🔐</div>
        <div class="brand-name">Secure<span>Login</span></div>
      </div>
      <h1 class="page-title">Create Account</h1>
      <p class="page-subtitle">// register_new_user.sh</p>

      <div id="reg-alerts"></div>

      <div class="field">
        <label>Username</label>
        <input type="text" id="reg-user" placeholder="your_username" autocomplete="username" />
      </div>
      <div class="field">
        <label>Email</label>
        <input type="email" id="reg-email" placeholder="you@example.com" autocomplete="email" />
      </div>
      <div class="field">
        <label>Password</label>
        <div class="password-wrapper">
          <input type="password" id="reg-pass" placeholder="Strong password" autocomplete="new-password" />
          <button class="toggle-pwd" type="button" onclick="togglePwd('reg-pass', this)">👁</button>
        </div>
        <div class="pwd-strength" id="pwd-str">
          <div class="pwd-bar" id="b1"></div>
          <div class="pwd-bar" id="b2"></div>
          <div class="pwd-bar" id="b3"></div>
          <div class="pwd-bar" id="b4"></div>
          <div class="pwd-bar" id="b5"></div>
          <span class="pwd-label" id="pwd-lbl">—</span>
        </div>
      </div>
      <div class="field">
        <label>Confirm Password</label>
        <div class="password-wrapper">
          <input type="password" id="reg-pass2" placeholder="Repeat password" autocomplete="new-password" />
          <button class="toggle-pwd" type="button" onclick="togglePwd('reg-pass2', this)">👁</button>
        </div>
      </div>

      <button class="btn btn-primary" id="reg-btn" onclick="doRegister()">Create Account</button>

      <div class="link-row">Already have an account? <a onclick="router.navigate('/login')">Sign in</a></div>
    </div>
  </div>`;

  // Password strength meter
  document.getElementById('reg-pass').addEventListener('input', function () {
    const score = passwordStrength(this.value);
    const bars = ['b1','b2','b3','b4','b5'];
    const labels = ['', 'Weak', 'Fair', 'Good', 'Strong', 'Great!'];
    const classes = ['', 'weak', 'weak', 'medium', 'strong', 'strong'];
    bars.forEach((id, i) => {
      const bar = document.getElementById(id);
      bar.className = 'pwd-bar' + (i < score ? ' ' + classes[score] : '');
    });
    document.getElementById('pwd-lbl').textContent = labels[score] || '—';
  });
}

async function doRegister() {
  const btn = document.getElementById('reg-btn');
  const alerts = document.getElementById('reg-alerts');
  const data = {
    username: document.getElementById('reg-user').value,
    email: document.getElementById('reg-email').value,
    password: document.getElementById('reg-pass').value,
    confirmPassword: document.getElementById('reg-pass2').value,
  };

  setLoading(btn, true);
  const res = await api('POST', '/register', data);
  setLoading(btn, false, 'Create Account');

  if (res.success) {
    showAlert(alerts, 'success', [res.message]);
    setTimeout(() => router.navigate('/login'), 1500);
  } else {
    showAlert(alerts, 'error', res.errors);
  }
}

/* LOGIN ─────────────────────────────────────────────────────── */
function renderLogin() {
  const urlErr = new URLSearchParams(location.search).get('error');
  app.innerHTML = `
  <div class="page">
    <div class="card">
      <div class="brand">
        <div class="brand-icon">🔐</div>
        <div class="brand-name">Secure<span>Login</span></div>
      </div>
      <h1 class="page-title">Welcome Back</h1>
      <p class="page-subtitle">// authenticate_user.sh</p>

      <div id="login-alerts">${urlErr ? `<div class="alert alert-error"><div class="alert-item">${urlErr}</div></div>` : ''}</div>

      <div class="field">
        <label>Username or Email</label>
        <input type="text" id="login-user" placeholder="username or email" autocomplete="username" />
      </div>
      <div class="field">
        <label>Password</label>
        <div class="password-wrapper">
          <input type="password" id="login-pass" placeholder="••••••••" autocomplete="current-password" />
          <button class="toggle-pwd" type="button" onclick="togglePwd('login-pass', this)">👁</button>
        </div>
      </div>

      <button class="btn btn-primary" id="login-btn" onclick="doLogin()">Sign In</button>

      <div class="link-row">No account? <a onclick="router.navigate('/register')">Register here</a></div>
    </div>
  </div>`;

  document.getElementById('login-pass').addEventListener('keydown', e => {
    if (e.key === 'Enter') doLogin();
  });
}

async function doLogin() {
  const btn = document.getElementById('login-btn');
  const alerts = document.getElementById('login-alerts');
  const data = {
    username: document.getElementById('login-user').value,
    password: document.getElementById('login-pass').value,
  };

  setLoading(btn, true);
  const res = await api('POST', '/login', data);
  setLoading(btn, false, 'Sign In');

  if (res.success) {
    if (res.requiresTwoFactor) {
      router.navigate('/2fa/verify');
    } else {
      router.navigate('/dashboard');
    }
  } else {
    showAlert(alerts, 'error', res.errors);
  }
}

/* 2FA VERIFY ────────────────────────────────────────────────── */
function renderTwoFAVerify() {
  app.innerHTML = `
  <div class="page">
    <div class="card">
      <div class="brand">
        <div class="brand-icon">🔐</div>
        <div class="brand-name">Secure<span>Login</span></div>
      </div>
      <h1 class="page-title">Two-Factor Auth</h1>
      <p class="page-subtitle">// verify_2fa_token.sh</p>
      <p class="otp-hint">Enter the 6-digit code from your authenticator app.</p>

      <div id="tfa-alerts"></div>

      <div class="field">
        <label>Authentication Code</label>
        <input type="text" id="tfa-token" placeholder="000 000" maxlength="7"
          autocomplete="one-time-code" inputmode="numeric"
          style="font-size:22px;letter-spacing:0.2em;text-align:center;" />
      </div>

      <button class="btn btn-primary" id="tfa-btn" onclick="doVerify2FA()">Verify Code</button>
      <div class="link-row"><a onclick="doLogout()">← Back to login</a></div>
    </div>
  </div>`;

  document.getElementById('tfa-token').addEventListener('keydown', e => {
    if (e.key === 'Enter') doVerify2FA();
  });
}

async function doVerify2FA() {
  const btn = document.getElementById('tfa-btn');
  const alerts = document.getElementById('tfa-alerts');
  const token = document.getElementById('tfa-token').value;

  setLoading(btn, true);
  const res = await api('POST', '/2fa/verify', { token });
  setLoading(btn, false, 'Verify Code');

  if (res.success) {
    router.navigate('/dashboard');
  } else {
    showAlert(alerts, 'error', res.errors);
  }
}

/* DASHBOARD ─────────────────────────────────────────────────── */
async function renderDashboard() {
  app.innerHTML = `
  <div class="page" style="padding-top: 80px;">
    <nav class="navbar">
      <div class="nav-brand"><span>🔐</span> Secure<span>Login</span></div>
      <button class="btn btn-ghost btn-sm" onclick="doLogout()">↩ Logout</button>
    </nav>
    <div class="dashboard-wrap">
      <div id="dash-content" style="text-align:center;color:var(--text-muted);padding:60px 0;">
        Loading…
      </div>
    </div>
  </div>`;

  const res = await api('GET', '/user');
  if (!res.success) { router.navigate('/login'); return; }

  const u = res.user;
  document.getElementById('dash-content').innerHTML = `
    <div class="dashboard-header">
      <div>
        <div class="greeting">Hello, <span>${u.username}</span> 👋</div>
        <div style="font-size:13px;color:var(--text-muted);margin-top:4px;">Last login: ${timeAgo(u.lastLoginAt)}</div>
      </div>
    </div>

    <div id="dash-alerts" style="margin-bottom:16px;"></div>

    <div class="grid-2" style="margin-bottom:16px;">
      <div class="stat-card">
        <div class="stat-label">Account</div>
        <div class="stat-value">${u.username}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Email</div>
        <div class="stat-value" style="font-size:14px;">${u.email}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Member Since</div>
        <div class="stat-value" style="font-size:15px;">${new Date(u.createdAt).toLocaleDateString()}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Two-Factor Auth</div>
        <div class="stat-value">
          <span class="badge ${u.twoFactorEnabled ? 'badge-on' : 'badge-off'}">
            ${u.twoFactorEnabled ? '✓ Enabled' : '○ Disabled'}
          </span>
        </div>
      </div>
    </div>

    <!-- 2FA Management -->
    <div class="card card-wide" id="tfa-panel">
      <div class="section-title">Two-Factor Authentication</div>
      ${u.twoFactorEnabled ? render2FADisablePanel() : render2FASetupButton()}
    </div>
  `;
}

function render2FASetupButton() {
  return `
    <p style="font-size:13px;color:var(--text-muted);margin-bottom:16px;">
      Protect your account with an authenticator app (Google Authenticator, Authy, etc.)
    </p>
    <div id="tfa-setup-area">
      <button class="btn btn-ghost" style="width:auto;" onclick="startSetup2FA()">
        📱 Enable 2FA
      </button>
    </div>`;
}

function render2FADisablePanel() {
  return `
    <p style="font-size:13px;color:var(--text-muted);margin-bottom:16px;">
      2FA is active. Enter your authenticator code to disable it.
    </p>
    <div class="field" style="max-width:240px;">
      <label>6-digit code</label>
      <input type="text" id="tfa-dis-token" placeholder="000 000" maxlength="7"
        inputmode="numeric" style="letter-spacing:0.15em;text-align:center;" />
    </div>
    <button class="btn btn-danger btn-sm" onclick="doDisable2FA()">Disable 2FA</button>`;
}

async function startSetup2FA() {
  document.getElementById('tfa-setup-area').innerHTML = `<p style="color:var(--text-muted);font-size:13px;">Loading QR code…</p>`;
  const res = await api('POST', '/2fa/setup');
  if (!res.success) {
    showAlert(document.getElementById('dash-alerts'), 'error', res.errors);
    return;
  }

  document.getElementById('tfa-setup-area').innerHTML = `
    <div class="qr-wrap">
      <p style="font-size:13px;color:var(--text-muted);">Scan with your authenticator app:</p>
      <img src="${res.qrCode}" alt="2FA QR Code" />
      <p style="font-size:11px;color:var(--text-muted);">Or enter manually:</p>
      <div class="secret-box">${res.secret}</div>
    </div>
    <div class="divider">Then verify</div>
    <div class="field">
      <label>Enter 6-digit code to confirm</label>
      <input type="text" id="tfa-en-token" placeholder="000 000" maxlength="7"
        inputmode="numeric" style="letter-spacing:0.15em;text-align:center;" />
    </div>
    <button class="btn btn-primary btn-sm" onclick="doEnable2FA()" style="width:auto;">
      ✓ Confirm &amp; Enable 2FA
    </button>
  `;
}

async function doEnable2FA() {
  const token = document.getElementById('tfa-en-token').value;
  const res = await api('POST', '/2fa/enable', { token });
  if (res.success) {
    showAlert(document.getElementById('dash-alerts'), 'success', [res.message]);
    setTimeout(() => renderDashboard(), 1200);
  } else {
    showAlert(document.getElementById('dash-alerts'), 'error', res.errors);
  }
}

async function doDisable2FA() {
  const token = document.getElementById('tfa-dis-token').value;
  const res = await api('POST', '/2fa/disable', { token });
  if (res.success) {
    showAlert(document.getElementById('dash-alerts'), 'success', [res.message]);
    setTimeout(() => renderDashboard(), 1200);
  } else {
    showAlert(document.getElementById('dash-alerts'), 'error', res.errors);
  }
}

async function doLogout() {
  await api('POST', '/logout');
  router.navigate('/login');
}

function togglePwd(inputId, btn) {
  const input = document.getElementById(inputId);
  if (input.type === 'password') {
    input.type = 'text';
    btn.textContent = '🔒';
  } else {
    input.type = 'password';
    btn.textContent = '👁';
  }
}

/* ── Route Registration ─────────────────────────────────────── */
router.register('/', renderLogin);
router.register('/login', renderLogin);
router.register('/register', renderRegister);
router.register('/dashboard', renderDashboard);
router.register('/2fa/verify', renderTwoFAVerify);
router.register('404', renderLogin);

// Initial render
router.render(location.pathname);

// Middleware: require authenticated session
function requireAuth(req, res, next) {
  if (!req.session || !req.session.userId) {
    return res.redirect('/login?error=Please+log+in+to+continue');
  }
  next();
}

// Middleware: require 2FA verified if user has 2FA enabled
function require2FA(req, res, next) {
  if (req.session.pendingTwoFactor) {
    return res.redirect('/2fa/verify');
  }
  next();
}

// Middleware: redirect if already logged in
function redirectIfLoggedIn(req, res, next) {
  if (req.session && req.session.userId && !req.session.pendingTwoFactor) {
    return res.redirect('/dashboard');
  }
  next();
}

module.exports = { requireAuth, require2FA, redirectIfLoggedIn };

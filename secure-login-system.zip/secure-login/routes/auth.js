const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { authenticator } = require('otplib');
const QRCode = require('qrcode');

const db = require('../config/database');
const { registerValidation, loginValidation, handleValidationErrors } = require('../utils/validators');
const { redirectIfLoggedIn } = require('../middleware/auth');

const SALT_ROUNDS = 12;

// ─── Register ───────────────────────────────────────────────────────────────

router.post('/register', registerValidation, handleValidationErrors, async (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Check duplicates
    if (db.findUserByUsername(username)) {
      return res.status(409).json({ success: false, errors: ['Username already taken'] });
    }
    if (db.findUserByEmail(email)) {
      return res.status(409).json({ success: false, errors: ['Email already registered'] });
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

    const user = {
      id: uuidv4(),
      username,
      email,
      passwordHash,
      twoFactorEnabled: false,
      twoFactorSecret: null,
      createdAt: new Date().toISOString(),
      lastLoginAt: null,
      loginAttempts: 0,
      lockedUntil: null,
    };

    db.createUser(user);

    return res.status(201).json({ success: true, message: 'Account created! Please log in.' });
  } catch (err) {
    console.error('Register error:', err);
    return res.status(500).json({ success: false, errors: ['Server error. Please try again.'] });
  }
});

// ─── Login ───────────────────────────────────────────────────────────────────

router.post('/login', loginValidation, handleValidationErrors, async (req, res) => {
  try {
    const { username, password } = req.body;

    const user = db.findUser(username);

    if (!user) {
      return res.status(401).json({ success: false, errors: ['Invalid credentials'] });
    }

    // Account lock check
    if (user.lockedUntil && new Date() < new Date(user.lockedUntil)) {
      const remaining = Math.ceil((new Date(user.lockedUntil) - new Date()) / 1000 / 60);
      return res.status(429).json({
        success: false,
        errors: [`Account locked. Try again in ${remaining} minute(s).`]
      });
    }

    // Compare password
    const valid = await bcrypt.compare(password, user.passwordHash);

    if (!valid) {
      const attempts = (user.loginAttempts || 0) + 1;
      const updates = { loginAttempts: attempts };

      if (attempts >= 5) {
        updates.lockedUntil = new Date(Date.now() + 15 * 60 * 1000).toISOString();
        updates.loginAttempts = 0;
      }
      db.updateUser(user.id, updates);
      return res.status(401).json({ success: false, errors: ['Invalid credentials'] });
    }

    // Reset attempts on success
    db.updateUser(user.id, {
      loginAttempts: 0,
      lockedUntil: null,
      lastLoginAt: new Date().toISOString()
    });

    // Handle 2FA
    if (user.twoFactorEnabled) {
      req.session.pendingTwoFactor = true;
      req.session.pendingUserId = user.id;
      return res.json({ success: true, requiresTwoFactor: true });
    }

    // Create session
    req.session.userId = user.id;
    req.session.username = user.username;
    return res.json({ success: true, requiresTwoFactor: false });

  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ success: false, errors: ['Server error. Please try again.'] });
  }
});

// ─── Logout ──────────────────────────────────────────────────────────────────

router.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) console.error('Session destroy error:', err);
    res.clearCookie('connect.sid');
    res.json({ success: true });
  });
});

// ─── 2FA Setup ───────────────────────────────────────────────────────────────

router.post('/2fa/setup', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, errors: ['Not authenticated'] });
  }

  try {
    const user = db.findUserById(req.session.userId);
    if (!user) return res.status(404).json({ success: false, errors: ['User not found'] });

    const secret = authenticator.generateSecret();
    const otpauth = authenticator.keyuri(user.username, 'SecureLogin', secret);
    const qrCode = await QRCode.toDataURL(otpauth);

    // Save secret temporarily (not enabled yet until verified)
    db.updateUser(user.id, { twoFactorSecret: secret });

    return res.json({ success: true, qrCode, secret });
  } catch (err) {
    console.error('2FA setup error:', err);
    return res.status(500).json({ success: false, errors: ['Server error'] });
  }
});

router.post('/2fa/enable', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, errors: ['Not authenticated'] });
  }

  const { token } = req.body;
  if (!token) return res.status(400).json({ success: false, errors: ['Token required'] });

  const user = db.findUserById(req.session.userId);
  if (!user || !user.twoFactorSecret) {
    return res.status(400).json({ success: false, errors: ['Setup 2FA first'] });
  }

  const valid = authenticator.check(token.replace(/\s/g, ''), user.twoFactorSecret);
  if (!valid) {
    return res.status(400).json({ success: false, errors: ['Invalid token. Try again.'] });
  }

  db.updateUser(user.id, { twoFactorEnabled: true });
  return res.json({ success: true, message: '2FA enabled successfully!' });
});

router.post('/2fa/disable', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false, errors: ['Not authenticated'] });
  }

  const { token } = req.body;
  if (!token) return res.status(400).json({ success: false, errors: ['Token required'] });

  const user = db.findUserById(req.session.userId);
  if (!user || !user.twoFactorEnabled) {
    return res.status(400).json({ success: false, errors: ['2FA not enabled'] });
  }

  const valid = authenticator.check(token.replace(/\s/g, ''), user.twoFactorSecret);
  if (!valid) {
    return res.status(400).json({ success: false, errors: ['Invalid token'] });
  }

  db.updateUser(user.id, { twoFactorEnabled: false, twoFactorSecret: null });
  return res.json({ success: true, message: '2FA disabled.' });
});

// ─── 2FA Verify (during login) ───────────────────────────────────────────────

router.post('/2fa/verify', (req, res) => {
  if (!req.session.pendingTwoFactor || !req.session.pendingUserId) {
    return res.status(401).json({ success: false, errors: ['No pending 2FA session'] });
  }

  const { token } = req.body;
  if (!token) return res.status(400).json({ success: false, errors: ['Token required'] });

  const user = db.findUserById(req.session.pendingUserId);
  if (!user) return res.status(404).json({ success: false, errors: ['User not found'] });

  const valid = authenticator.check(token.replace(/\s/g, ''), user.twoFactorSecret);
  if (!valid) {
    return res.status(400).json({ success: false, errors: ['Invalid authentication code'] });
  }

  // Promote to full session
  req.session.userId = user.id;
  req.session.username = user.username;
  delete req.session.pendingTwoFactor;
  delete req.session.pendingUserId;

  return res.json({ success: true });
});

// ─── User info (for dashboard) ────────────────────────────────────────────────

router.get('/user', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ success: false });
  }
  const user = db.findUserById(req.session.userId);
  if (!user) return res.status(404).json({ success: false });

  return res.json({
    success: true,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      twoFactorEnabled: user.twoFactorEnabled,
      createdAt: user.createdAt,
      lastLoginAt: user.lastLoginAt,
    }
  });
});

module.exports = router;

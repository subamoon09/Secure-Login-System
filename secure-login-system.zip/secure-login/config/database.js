const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../data/users.json');

// Ensure data directory exists
const dataDir = path.join(__dirname, '../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize DB file
if (!fs.existsSync(DB_PATH)) {
  fs.writeFileSync(DB_PATH, JSON.stringify({ users: [] }, null, 2));
}

function readDB() {
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch {
    return { users: [] };
  }
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

const db = {
  // Find user by username or email
  findUser(identifier) {
    const data = readDB();
    return data.users.find(
      u => u.username === identifier || u.email === identifier
    ) || null;
  },

  findUserById(id) {
    const data = readDB();
    return data.users.find(u => u.id === id) || null;
  },

  findUserByUsername(username) {
    const data = readDB();
    return data.users.find(u => u.username === username) || null;
  },

  findUserByEmail(email) {
    const data = readDB();
    return data.users.find(u => u.email === email) || null;
  },

  createUser(user) {
    const data = readDB();
    data.users.push(user);
    writeDB(data);
    return user;
  },

  updateUser(id, updates) {
    const data = readDB();
    const idx = data.users.findIndex(u => u.id === id);
    if (idx === -1) return null;
    data.users[idx] = { ...data.users[idx], ...updates };
    writeDB(data);
    return data.users[idx];
  },

  getAllUsers() {
    return readDB().users;
  }
};

module.exports = db;
